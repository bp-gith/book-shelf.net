import { useEffect, useMemo, useState } from 'react'
import './App.css'

const emptyBook = {
  title: '',
  author: '',
  genre: '',
  yearPublished: new Date().getFullYear(),
  description: '',
  isAvailable: true,
}

const genreColors = {
  Fiction: 'lavender',
  'Science Fiction': 'blue',
  Memoir: 'peach',
  'Personal Growth': 'green',
  'Historical Fiction': 'rose',
  'Art & Design': 'yellow',
  Fantasy: 'green',
}

function Icon({ name, size = 18 }) {
  const paths = {
    search: <><circle cx="11" cy="11" r="7" /><path d="m16 16 4 4" /></>,
    plus: <><path d="M12 5v14" /><path d="M5 12h14" /></>,
    close: <><path d="m18 6-12 12" /><path d="m6 6 12 12" /></>,
    book: <><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" /><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z" /></>,
    edit: <><path d="M12 20h9" /><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z" /></>,
    trash: <><path d="M3 6h18" /><path d="M8 6V4h8v2" /><path d="m19 6-1 14H6L5 6" /><path d="M10 11v5M14 11v5" /></>,
    arrow: <><path d="M7 17 17 7" /><path d="M7 7h10v10" /></>,
  }

  return (
    <svg
      aria-hidden="true"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  )
}

function BookForm({ book, onClose, onSave, saving }) {
  const [form, setForm] = useState(book ?? emptyBook)
  const [error, setError] = useState('')

  function updateField(event) {
    const { name, value, type, checked } = event.target
    setForm((current) => ({ ...current, [name]: type === 'checkbox' ? checked : value }))
  }

  async function submit(event) {
    event.preventDefault()
    setError('')
    try {
      await onSave({
        ...form,
        yearPublished: Number(form.yearPublished),
      })
    } catch (saveError) {
      setError(saveError.message)
    }
  }

  return (
    <div className="modal-backdrop" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <section className="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">
        <div className="modal-heading">
          <div>
            <p className="eyebrow">{book ? 'YOUR COLLECTION' : 'NEW ARRIVAL'}</p>
            <h2 id="modal-title">{book ? 'Edit book' : 'Add a book'}</h2>
          </div>
          <button className="icon-button" type="button" onClick={onClose} aria-label="Close dialog">
            <Icon name="close" />
          </button>
        </div>

        <form className="book-form" onSubmit={submit}>
          <label>
            Book title
            <input name="title" value={form.title} onChange={updateField} maxLength="120" required autoFocus placeholder="e.g. The Secret History" />
          </label>
          <label>
            Author
            <input name="author" value={form.author} onChange={updateField} maxLength="100" required placeholder="e.g. Donna Tartt" />
          </label>
          <div className="form-row">
            <label>
              Genre
              <input name="genre" value={form.genre} onChange={updateField} maxLength="50" required placeholder="e.g. Fiction" />
            </label>
            <label>
              Year published
              <input name="yearPublished" type="number" min="1000" max="2100" value={form.yearPublished} onChange={updateField} required />
            </label>
          </div>
          <label>
            A little about it
            <textarea name="description" rows="3" maxLength="500" value={form.description} onChange={updateField} placeholder="What makes this one worth picking up?" />
          </label>
          <label className="availability-toggle">
            <input name="isAvailable" type="checkbox" checked={form.isAvailable} onChange={updateField} />
            <span>Available to borrow</span>
          </label>
          {error && <p className="form-error" role="alert">{error}</p>}
          <div className="form-actions">
            <button type="button" className="button button-quiet" onClick={onClose}>Cancel</button>
            <button type="submit" className="button button-primary" disabled={saving}>
              {saving ? 'Saving…' : book ? 'Save changes' : 'Add to library'}
            </button>
          </div>
        </form>
      </section>
    </div>
  )
}

function BookCard({ book, onEdit, onDelete }) {
  const color = genreColors[book.genre] ?? 'lavender'
  const initials = book.title
    .split(/\s+/)
    .slice(0, 2)
    .map((word) => word[0])
    .join('')
    .toUpperCase()

  return (
    <article className="book-card">
      <div className={`book-cover cover-${color}`}>
        <span className="cover-mark"><Icon name="book" size={22} /></span>
        <span className="cover-initials">{initials}</span>
        <span className="cover-year">{book.yearPublished}</span>
      </div>
      <div className="book-details">
        <div className="book-meta">
          <span className={`genre-pill genre-${color}`}>{book.genre}</span>
          <div className="card-actions">
            <button className="icon-button" type="button" onClick={() => onEdit(book)} aria-label={`Edit ${book.title}`}>
              <Icon name="edit" size={16} />
            </button>
            <button className="icon-button delete-action" type="button" onClick={() => onDelete(book)} aria-label={`Delete ${book.title}`}>
              <Icon name="trash" size={16} />
            </button>
          </div>
        </div>
        <h3>{book.title}</h3>
        <p className="book-author">by {book.author}</p>
        <p className="book-description">{book.description || 'A new addition to the shelves, waiting to be discovered.'}</p>
        <div className="book-footer">
          <span className={book.isAvailable ? 'availability available' : 'availability borrowed'}>
            <span className="availability-dot" />
            {book.isAvailable ? 'On the shelf' : 'Checked out'}
          </span>
          <button className="text-button" type="button" onClick={() => onEdit(book)}>
            Details <Icon name="arrow" size={14} />
          </button>
        </div>
      </div>
    </article>
  )
}

function App() {
  const [books, setBooks] = useState([])
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState('All books')
  const [modalBook, setModalBook] = useState(undefined)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  async function loadBooks() {
    setError('')
    try {
      const response = await fetch('/api/books')
      if (!response.ok) throw new Error('The library catalog could not be reached. Check that the API is running.')
      setBooks(await response.json())
    } catch (loadError) {
      setError(loadError.message)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    let active = true

    fetch('/api/books')
      .then((response) => {
        if (!response.ok) throw new Error('The library catalog could not be reached. Check that the API is running.')
        return response.json()
      })
      .then((data) => {
        if (active) setBooks(data)
      })
      .catch((loadError) => {
        if (active) setError(loadError.message)
      })
      .finally(() => {
        if (active) setLoading(false)
      })

    return () => {
      active = false
    }
  }, [])

  const availableCount = books.filter((book) => book.isAvailable).length
  const genres = useMemo(() => ['All books', ...new Set(books.map((book) => book.genre).sort())], [books])
  const filteredBooks = books.filter((book) => {
    const term = search.trim().toLowerCase()
    const matchesSearch = !term || `${book.title} ${book.author} ${book.genre}`.toLowerCase().includes(term)
    const matchesFilter = filter === 'All books' || book.genre === filter
    return matchesSearch && matchesFilter
  })

  async function saveBook(book) {
    setSaving(true)
    const isEditing = Boolean(book.id)
    try {
      const response = await fetch(isEditing ? `/api/books/${book.id}` : '/api/books', {
        method: isEditing ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(book),
      })
      if (!response.ok) {
        const detail = await response.json().catch(() => null)
        throw new Error(detail?.detail ?? 'Could not save this book. Please check the details and try again.')
      }
      await loadBooks()
      setModalBook(undefined)
    } finally {
      setSaving(false)
    }
  }

  async function deleteBook(book) {
    if (!window.confirm(`Remove "${book.title}" from the catalog?`)) return
    try {
      const response = await fetch(`/api/books/${book.id}`, { method: 'DELETE' })
      if (!response.ok) throw new Error('Could not remove this book. Please try again.')
      await loadBooks()
    } catch (deleteError) {
      setError(deleteError.message)
    }
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="/" aria-label="Shelf Notes home">
          <span className="brand-icon"><Icon name="book" size={19} /></span>
          <span>shelf<span className="brand-light">notes</span></span>
        </a>
        <nav className="top-nav" aria-label="Main navigation">
          <a className="nav-active" href="#collection">Collection</a>
          <a href="#about">About</a>
        </nav>
        <button className="button button-primary top-add" onClick={() => setModalBook(null)}>
          <Icon name="plus" size={17} /> Add a book
        </button>
      </header>

      <main>
        <section className="hero">
          <div className="hero-copy">
            <p className="eyebrow"><span className="eyebrow-line" /> A LITTLE SPACE FOR BIG STORIES</p>
            <h1>Every book has<br />a <em>place</em> here.</h1>
            <p className="hero-description">A thoughtful home for the stories you love, the ones you lend, and the ones you can’t wait to read next.</p>
            <a className="hero-link" href="#collection">Explore the collection <Icon name="arrow" size={15} /></a>
          </div>
          <div className="hero-art" aria-hidden="true">
            <div className="sun-disc" />
            <div className="art-book art-book-one"><span>THE<br />WILD<br />PLACES</span><i>ROBERT MACFARLANE</i></div>
            <div className="art-book art-book-two"><span>WAYS OF<br />SEEING</span><i>JOHN BERGER</i></div>
            <div className="art-book art-book-three"><span>STILL<br />LIFE</span><i>ALICE OSEMAN</i></div>
            <div className="art-sprig">✳</div>
            <span className="art-caption">a quiet corner<br />for curious minds</span>
          </div>
        </section>

        <section className="stats-row" aria-label="Library summary">
          <div className="stat"><strong>{books.length.toString().padStart(2, '0')}</strong><span>books on our shelves</span></div>
          <span className="stat-divider" />
          <div className="stat"><strong>{availableCount.toString().padStart(2, '0')}</strong><span>ready for a new reader</span></div>
          <span className="stat-note">GOOD BOOKS, GOOD COMPANY <span>✳</span></span>
        </section>

        <section className="collection-section" id="collection">
          <div className="section-heading">
            <div>
              <p className="eyebrow">THE LIBRARY</p>
              <h2>On the shelves <span>({books.length})</span></h2>
            </div>
            <button className="button button-outline" onClick={() => setModalBook(null)}>
              <Icon name="plus" size={16} /> Add to collection
            </button>
          </div>

          <div className="toolbar">
            <div className="search-box">
              <Icon name="search" size={18} />
              <input aria-label="Search books" placeholder="Find a title, author, or mood…" value={search} onChange={(event) => setSearch(event.target.value)} />
              <kbd>⌘ K</kbd>
            </div>
            <div className="filter-list" aria-label="Filter by genre">
              {genres.map((genre) => (
                <button key={genre} className={`filter-chip ${filter === genre ? 'filter-selected' : ''}`} onClick={() => setFilter(genre)}>
                  {genre}
                </button>
              ))}
            </div>
          </div>

          {error && <div className="error-banner" role="alert">{error} <button onClick={loadBooks}>Try again</button></div>}
          {loading ? (
            <div className="loading-state"><span className="spinner" /> Setting the shelves…</div>
          ) : filteredBooks.length ? (
            <div className="book-grid">
              {filteredBooks.map((book) => <BookCard key={book.id} book={book} onEdit={setModalBook} onDelete={deleteBook} />)}
            </div>
          ) : (
            <div className="empty-state">
              <span className="empty-icon"><Icon name="book" size={24} /></span>
              <h3>{books.length ? 'No books found' : 'The shelves are waiting'}</h3>
              <p>{books.length ? 'Try another search or genre.' : 'Add the first book to start your collection.'}</p>
              {!books.length && <button className="button button-primary" onClick={() => setModalBook(null)}><Icon name="plus" size={16} /> Add a book</button>}
            </div>
          )}
        </section>

        <section className="about-brief" id="about" aria-labelledby="about-title">
          <p className="eyebrow">ABOUT SHELF NOTES</p>
          <h2 id="about-title">A little room for a lot of imagination.</h2>
          <p>
            Shelf Notes is a full-stack library catalog built with React and ASP.NET Core.
            Browse and search books, manage the collection, and track what is ready to borrow.
          </p>
        </section>
      </main>

      <footer className="footer">
        <a className="brand footer-brand" href="#"><span className="brand-icon"><Icon name="book" size={17} /></span><span>shelf<span className="brand-light">notes</span></span></a>
        <span>A little room for a lot of imagination.</span>
        <a className="footer-top" href="#">BACK TO TOP ↑</a>
      </footer>

      {modalBook !== undefined && (
        <BookForm
          key={modalBook?.id ?? 'new-book'}
          book={modalBook}
          onClose={() => setModalBook(undefined)}
          onSave={saveBook}
          saving={saving}
        />
      )}
    </div>
  )
}

export default App
