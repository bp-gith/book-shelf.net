# Shelf Notes — Library Catalog

A small full-stack library catalog for tracking books and their availability.
The project is split into a React/Vite frontend and an ASP.NET Core Web API.

The standalone [Shelf Notes project poster](./Shelf-Notes-Project-Poster.pdf)
summarizes the project, features, architecture, and API routes.

## Requirements

- .NET 10 SDK
- Node.js 20.19+ or 22.12+

## Run locally

Open two terminals from this folder.

**Terminal 1 — API**

```powershell
dotnet run --project .\server\server.csproj --launch-profile http
```

The API listens at `http://localhost:5018`. Its OpenAPI document is available
at `http://localhost:5018/openapi/v1.json`.

**Terminal 2 — frontend**

```powershell
cd .\client
npm install
npm run dev
```

Open the Vite URL shown in the terminal (normally `http://localhost:5173`).
The frontend proxies `/api` requests to the local .NET API.

## Features

- Browse, search, and filter the sample collection by genre.
- Add, edit, and remove books.
- Mark books as available or checked out.
- Explore the API contract in the OpenAPI document.

The sample catalog is held in memory and resets to its starter books when the
API restarts. It is intended as a runnable CRUD example, not permanent storage.

## API routes

| Method | Route | Description |
| --- | --- | --- |
| GET | `/api/books` | List books |
| GET | `/api/books/{id}` | Get one book |
| POST | `/api/books` | Add a book |
| PUT | `/api/books/{id}` | Update a book |
| DELETE | `/api/books/{id}` | Remove a book |

Example requests are in [server/server.http](./server/server.http).
