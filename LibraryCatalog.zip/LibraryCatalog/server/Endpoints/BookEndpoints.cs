using System.ComponentModel.DataAnnotations;
using LibraryCatalog.Api.Contracts;
using LibraryCatalog.Api.Services;
using Microsoft.AspNetCore.Http.HttpResults;

namespace LibraryCatalog.Api.Endpoints;

public static class BookEndpoints
{
    public static void MapBookEndpoints(this WebApplication app)
    {
        var books = app.MapGroup("/api/books").WithTags("Books");

        books.MapGet("/", (
                IBookCatalogService catalog,
                CancellationToken cancellationToken) =>
            {
                cancellationToken.ThrowIfCancellationRequested();
                return TypedResults.Ok(catalog.GetAll());
            })
            .WithName("GetBooks")
            .WithSummary("List all books")
            .WithDescription("Returns every book in the catalog, sorted by title.")
            .Produces<IReadOnlyList<BookResponse>>(StatusCodes.Status200OK);

        books.MapGet("/{id:int}", Results<Ok<BookResponse>, NotFound> (
                int id,
                IBookCatalogService catalog,
                CancellationToken cancellationToken) =>
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    return catalog.GetById(id) is { } book
                        ? TypedResults.Ok(book)
                        : TypedResults.NotFound();
                })
            .WithName("GetBookById")
            .WithSummary("Get a book by ID")
            .WithDescription("Returns the catalog entry for the requested ID.")
            .Produces<BookResponse>(StatusCodes.Status200OK)
            .Produces(StatusCodes.Status404NotFound);

        books.MapPost("/", Results<Created<BookResponse>, ValidationProblem> (
                CreateBookRequest request,
                IBookCatalogService catalog,
                CancellationToken cancellationToken) =>
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (GetValidationErrors(request) is { Count: > 0 } errors)
                    {
                        return TypedResults.ValidationProblem(errors);
                    }

                    var book = catalog.Create(request);
                    return TypedResults.Created($"/api/books/{book.Id}", book);
                })
            .WithName("CreateBook")
            .WithSummary("Add a book")
            .WithDescription("Adds a validated book to the catalog.")
            .Produces<BookResponse>(StatusCodes.Status201Created)
            .ProducesValidationProblem();

        books.MapPut("/{id:int}", Results<Ok<BookResponse>, NotFound, ValidationProblem> (
                int id,
                UpdateBookRequest request,
                IBookCatalogService catalog,
                CancellationToken cancellationToken) =>
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (GetValidationErrors(request) is { Count: > 0 } errors)
                    {
                        return TypedResults.ValidationProblem(errors);
                    }

                    return catalog.Update(id, request) is { } book
                        ? TypedResults.Ok(book)
                        : TypedResults.NotFound();
                })
            .WithName("UpdateBook")
            .WithSummary("Update a book")
            .WithDescription("Replaces the catalog details for the requested book.")
            .Produces<BookResponse>(StatusCodes.Status200OK)
            .ProducesValidationProblem()
            .Produces(StatusCodes.Status404NotFound);

        books.MapDelete("/{id:int}", Results<NoContent, NotFound> (
                int id,
                IBookCatalogService catalog,
                CancellationToken cancellationToken) =>
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    return catalog.Delete(id)
                        ? TypedResults.NoContent()
                        : TypedResults.NotFound();
                })
            .WithName("DeleteBook")
            .WithSummary("Remove a book")
            .WithDescription("Removes the requested book from the catalog.")
            .Produces(StatusCodes.Status204NoContent)
            .Produces(StatusCodes.Status404NotFound);
    }

    private static Dictionary<string, string[]> GetValidationErrors<T>(T request)
    {
        var validationResults = new List<ValidationResult>();
        var validationContext = new ValidationContext(request!);
        Validator.TryValidateObject(request!, validationContext, validationResults, validateAllProperties: true);

        return validationResults
            .SelectMany(result => result.MemberNames.Select(member => (member, result.ErrorMessage)))
            .GroupBy(item => item.member)
            .ToDictionary(
                group => group.Key,
                group => group.Select(item => item.ErrorMessage ?? "The value is invalid.").ToArray());
    }
}
