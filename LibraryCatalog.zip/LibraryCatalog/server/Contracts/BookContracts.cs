using System.ComponentModel.DataAnnotations;

namespace LibraryCatalog.Api.Contracts;

/// <summary>Book data returned by the library catalog.</summary>
public sealed record BookResponse(
    int Id,
    string Title,
    string Author,
    string Genre,
    int YearPublished,
    string Description,
    bool IsAvailable);

/// <summary>Fields required to add a book to the library catalog.</summary>
public sealed record CreateBookRequest
{
    [Required, MaxLength(120)]
    public required string Title { get; init; }

    [Required, MaxLength(100)]
    public required string Author { get; init; }

    [Required, MaxLength(50)]
    public required string Genre { get; init; }

    [Range(1000, 2100)]
    public required int YearPublished { get; init; }

    [MaxLength(500)]
    public string Description { get; init; } = string.Empty;

    public bool IsAvailable { get; init; } = true;
}

/// <summary>Fields used to update a book in the library catalog.</summary>
public sealed record UpdateBookRequest
{
    [Required, MaxLength(120)]
    public required string Title { get; init; }

    [Required, MaxLength(100)]
    public required string Author { get; init; }

    [Required, MaxLength(50)]
    public required string Genre { get; init; }

    [Range(1000, 2100)]
    public required int YearPublished { get; init; }

    [MaxLength(500)]
    public string Description { get; init; } = string.Empty;

    public bool IsAvailable { get; init; } = true;
}
