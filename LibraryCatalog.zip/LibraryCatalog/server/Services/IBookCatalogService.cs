using LibraryCatalog.Api.Contracts;

namespace LibraryCatalog.Api.Services;

public interface IBookCatalogService
{
    IReadOnlyList<BookResponse> GetAll();
    BookResponse? GetById(int id);
    BookResponse Create(CreateBookRequest request);
    BookResponse? Update(int id, UpdateBookRequest request);
    bool Delete(int id);
}
