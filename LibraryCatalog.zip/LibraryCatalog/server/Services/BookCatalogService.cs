using System.Collections.Concurrent;
using LibraryCatalog.Api.Contracts;

namespace LibraryCatalog.Api.Services;

internal sealed record Book(
    int Id,
    string Title,
    string Author,
    string Genre,
    int YearPublished,
    string Description,
    bool IsAvailable);

public sealed class BookCatalogService : IBookCatalogService
{
    private readonly ConcurrentDictionary<int, Book> _books = new();
    private int _nextId = 8;

    public BookCatalogService()
    {
        var seedBooks = new[]
        {
            new Book(1, "The Midnight Library", "Matt Haig", "Fiction", 2020, "Between life and death there is a library, and within it, the chance to try another life.", true),
            new Book(2, "Project Hail Mary", "Andy Weir", "Science Fiction", 2021, "A lone astronaut must save Earth in this high-stakes space adventure.", true),
            new Book(3, "Educated", "Tara Westover", "Memoir", 2018, "A memoir about family, self-invention, and the transformative power of education.", false),
            new Book(4, "Atomic Habits", "James Clear", "Personal Growth", 2018, "A practical guide to building good habits and breaking bad ones.", true),
            new Book(5, "Pachinko", "Min Jin Lee", "Historical Fiction", 2017, "Four generations of a Korean family navigate love, identity, and belonging.", true),
            new Book(6, "The Creative Act", "Rick Rubin", "Art & Design", 2023, "A generous guide to finding inspiration and making meaningful work.", true),
            new Book(7, "Dune", "Frank Herbert", "Science Fiction", 1965, "A young heir discovers his destiny on the desert planet Arrakis.", false),
            new Book(8, "Crying in H Mart", "Michelle Zauner", "Memoir", 2021, "A moving story of food, family, grief, and finding a way home.", true)
        };

        foreach (var book in seedBooks)
        {
            _books.TryAdd(book.Id, book);
        }
    }

    public IReadOnlyList<BookResponse> GetAll() =>
        _books.Values
            .OrderBy(book => book.Title, StringComparer.OrdinalIgnoreCase)
            .Select(ToResponse)
            .ToArray();

    public BookResponse? GetById(int id) =>
        _books.TryGetValue(id, out var book) ? ToResponse(book) : null;

    public BookResponse Create(CreateBookRequest request)
    {
        var id = Interlocked.Increment(ref _nextId);
        var book = new Book(
            id,
            request.Title.Trim(),
            request.Author.Trim(),
            request.Genre.Trim(),
            request.YearPublished,
            request.Description.Trim(),
            request.IsAvailable);

        _books[id] = book;
        return ToResponse(book);
    }

    public BookResponse? Update(int id, UpdateBookRequest request)
    {
        while (_books.TryGetValue(id, out var existing))
        {
            var updated = existing with
            {
                Title = request.Title.Trim(),
                Author = request.Author.Trim(),
                Genre = request.Genre.Trim(),
                YearPublished = request.YearPublished,
                Description = request.Description.Trim(),
                IsAvailable = request.IsAvailable
            };

            if (_books.TryUpdate(id, updated, existing))
            {
                return ToResponse(updated);
            }
        }

        return null;
    }

    public bool Delete(int id) => _books.TryRemove(id, out _);

    private static BookResponse ToResponse(Book book) =>
        new(
            book.Id,
            book.Title,
            book.Author,
            book.Genre,
            book.YearPublished,
            book.Description,
            book.IsAvailable);
}
